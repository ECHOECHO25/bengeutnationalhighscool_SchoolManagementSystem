<div>
    <div class="py-10">
        <main class="w-full max-w-7xl  mx-auto p-6 lg:p-8">
            <!-- Welcome Banner -->
            <div
                class="bg-gradient-to-r from-blue-600 to-blue-700 dark:from-blue-800 dark:to-blue-900 rounded-xl shadow-md overflow-hidden mb-10">
                <div class="p-8 text-white text-center">
                    <h1 class="text-3xl font-bold mb-3">Welcome to <?php echo e(config('app.name')); ?></h1>
                    <p class="text-blue-100">School Management System</p>
                </div>
            </div>

            <div class="mb-10">
                <h1 class="font-semibold text-2xl text-white uppercase">STATISTICS</h1>
                <div class="mt-5 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div
                        class="bg-white hover:cursor-pointer hover:bg-gray-700 hover:text-white relative overflow-hidden rounded-3xl shadow p-6 ">
                        <p class="text-4xl font-bold  mt-8"><?php echo e($studentCount); ?></p>
                        <span class="font-medium ">Students</span>
                        <div class="absolute -right-5 bottom-0">
                            <?php if (isset($component)) { $__componentOriginald8f13165f4c2b8b9cfa41ed983b09d55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8f13165f4c2b8b9cfa41ed983b09d55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.student','data' => ['class' => 'h-40 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.student'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-40 ']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8f13165f4c2b8b9cfa41ed983b09d55)): ?>
<?php $attributes = $__attributesOriginald8f13165f4c2b8b9cfa41ed983b09d55; ?>
<?php unset($__attributesOriginald8f13165f4c2b8b9cfa41ed983b09d55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8f13165f4c2b8b9cfa41ed983b09d55)): ?>
<?php $component = $__componentOriginald8f13165f4c2b8b9cfa41ed983b09d55; ?>
<?php unset($__componentOriginald8f13165f4c2b8b9cfa41ed983b09d55); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div
                        class="bg-white hover:cursor-pointer hover:bg-gray-700 hover:text-white relative overflow-hidden rounded-3xl shadow p-6 ">
                        <p class="text-4xl font-bold  mt-8"><?php echo e($teacherCount); ?></p>
                        <span class="font-medium ">Teachers</span>
                        <div class="absolute -right-0 bottom-0">
                            <?php if (isset($component)) { $__componentOriginal2432b12697fa5cedcd944a7d197f3639 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2432b12697fa5cedcd944a7d197f3639 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.teacher','data' => ['class' => 'h-32 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shared.teacher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-32 ']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2432b12697fa5cedcd944a7d197f3639)): ?>
<?php $attributes = $__attributesOriginal2432b12697fa5cedcd944a7d197f3639; ?>
<?php unset($__attributesOriginal2432b12697fa5cedcd944a7d197f3639); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2432b12697fa5cedcd944a7d197f3639)): ?>
<?php $component = $__componentOriginal2432b12697fa5cedcd944a7d197f3639; ?>
<?php unset($__componentOriginal2432b12697fa5cedcd944a7d197f3639); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="mt-5 bg-white p-6 rounded-3xl shadow">
                    <div id="chart-container" style="height:400px;"></div>

                    <script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>

                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            var dom = document.getElementById('chart-container');
                            var myChart = echarts.init(dom, null, {
                                renderer: 'canvas',
                                useDirtyRect: false
                            });

                            var option = {
                                title: {
                                    text: 'STUDENTS PER GRADE LEVEL',
                                    left: 'center'
                                },
                                tooltip: {
                                    trigger: 'item'
                                },
                                legend: {
                                    orient: 'horizontal',
                                    bottom: '0'
                                },
                                series: [{
                                    name: 'Grade Level',
                                    type: 'pie',
                                    radius: ['30%', '70%'],
                                    center: ['50%', '50%'],
                                    roseType: 'area',
                                    itemStyle: {
                                        borderRadius: 8
                                    },
                                    data: <?php echo json_encode($gradeLevelCounts, 15, 512) ?>
                                }]
                            };

                            myChart.setOption(option);
                            window.addEventListener('resize', () => myChart.resize());
                        });
                    </script>
                </div>


            </div>

            <!-- School Image -->
            <div class="relative h-64 w-full rounded-lg shadow-md overflow-hidden mb-10">
                <img src="<?php echo e(asset('images/BeNHS.jpg')); ?>" alt="Benguet National High School Campus"
                    class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <div class="text-center px-4">
                        <h2 class="text-2xl md:text-3xl font-bold text-white mb-2">Benguet National High School</h2>
                        <p class="text-lg text-blue-100">Excellence in Education </p>
                    </div>
                </div>
            </div>

            <!-- School Description -->

        </main>
    </div>
</div>
<?php /**PATH F:\WEB PROJECTS\FREELANCE\benguetnationalhighschool\resources\views/livewire/admin/admin-dashboard.blade.php ENDPATH**/ ?>