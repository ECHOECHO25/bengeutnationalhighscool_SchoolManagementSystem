    
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Benguet National High School" <?php echo e($attributes); ?>>
<?php /**PATH F:\WEB PROJECTS\FREELANCE\benguetnationalhighschool\resources\views/components/application-logo.blade.php ENDPATH**/ ?>