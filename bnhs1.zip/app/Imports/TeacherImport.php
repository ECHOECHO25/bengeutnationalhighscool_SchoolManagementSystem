<?php
namespace App\Imports;

use App\Models\Teacher;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToCollection;

class TeacherImport implements ToCollection
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function collection(Collection $rows)
    {
        foreach ($rows as $row) {
            if (! isset($row[0]) || strtolower($row[0]) === 'lastname') {
                continue;
            }

           
            if (empty($row[4])) {
                continue; 
            }

         
            $user = User::firstOrCreate(
                ['email' => $row[4]],
                [
                    'name'     => trim($row[1] . ' ' . $row[0]),
                    'password' => Hash::make($row[5]), 
                    'role'     => 'teacher',
                ]
            );

            $teacherExists = Teacher::where('user_id', $user->id)->exists();
            if (! $teacherExists) {
                Teacher::create([
                    'lastname'   => trim($row[0]),
                    'firstname'  => trim($row[1]),
                    'middlename' => trim($row[2] ?? ''),
                    'birthdate'  => ! empty($row[3]) ? Carbon::parse($row[3]) : null,
                    'user_id'    => $user->id,
                    'teacher_identification_number' => isset($row[5]) ? trim($row[5]) : null, 
                ]);
            }
        }
    }
}
