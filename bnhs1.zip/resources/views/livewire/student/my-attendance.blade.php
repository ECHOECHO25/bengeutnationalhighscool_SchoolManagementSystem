<div>
{{ $this->table }}
</div>
