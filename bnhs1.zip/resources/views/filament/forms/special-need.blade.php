<div>
    <h1 class="font-semibold uppercase text-sm text-gray-700">Special Needs Information</h1>
</div>