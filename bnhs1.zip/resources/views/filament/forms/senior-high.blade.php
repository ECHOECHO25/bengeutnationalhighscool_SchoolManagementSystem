<div>
    <h1 class="font-semibold uppercase text-sm text-gray-700">SENIOR HIGH INFORMATION</h1>
</div>