<div class="mb-2">
    <img src="{{asset('images/student.png')}}" class="h-20 " alt="" >
</div>