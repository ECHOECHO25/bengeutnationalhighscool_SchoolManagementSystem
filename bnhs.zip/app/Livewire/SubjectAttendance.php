<?php

namespace App\Livewire;

use Livewire\Component;

class SubjectAttendance extends Component
{
    public function render()
    {
        return view('livewire.subject-attendance');
    }
}
