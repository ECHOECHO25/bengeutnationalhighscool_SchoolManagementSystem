<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class ExamRecord extends Component
{
    public function render()
    {
        return view('livewire.admin.exam-record');
    }
}
