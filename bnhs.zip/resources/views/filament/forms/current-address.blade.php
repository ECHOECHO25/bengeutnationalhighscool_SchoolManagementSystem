<div>
    <h1 class="font-semibold uppercase text-sm text-gray-700">Current Address</h1>
</div>