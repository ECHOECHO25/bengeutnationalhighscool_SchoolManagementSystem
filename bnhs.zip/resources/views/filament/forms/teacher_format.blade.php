<div>
    <div class="border-l-8 border p-2 border-main rounded-xl">
        <h1 class="font-semibold uppercase text-sm text-gray-700">File Format Requirements:</h1>
        <p class="text-gray-500 text-sm">Required columns: Lastname, Firstname, Email, </p>
        <p class="text-gray-500 text-sm">Optional columns: Middlename, Birthdate</p>
        <p class="text-gray-500 text-sm">Email must be unique</p>
        <p class="text-gray-500 text-sm">Max file size: 2MB</p>
    </div>
</div>
