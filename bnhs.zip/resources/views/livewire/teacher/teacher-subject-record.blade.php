<div>
    <div class="py-10">
        <div class="max-w-7xl mx-auto bg-gray-300 p-5 rounded-2xl">
            <div>
                {{$this->table}}
            </div>
        </div>
    </div>
</div>
