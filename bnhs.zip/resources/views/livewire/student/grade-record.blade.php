<div>
  <div class="py-10">
        <div class="max-w-7xl mx-auto">
            <div class="bg-white rounded-2xl p-5">
                <h1 class="uppercase text-2xl font-bold text-gray-700">My Grades</h1>
                <span class="text-gray-600 font-medium">This shows all the grades you have in {{ auth()->user()->student->gradeLevel->name . ' - ' . auth()->user()->student->gradeLevel->department }}</span>
                <div class="mt-3">
                    {{$this->table}}
                </div>
            </div>
        </div>
    </div>
</div>
