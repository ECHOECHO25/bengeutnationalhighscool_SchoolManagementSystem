<div>
    <h1 class="font-semibold uppercase text-sm text-gray-700">Classroom Assignment</h1>
</div>