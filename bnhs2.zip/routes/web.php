<?php

use App\Livewire\Admin\AdminDashboard;
use App\Livewire\Admin\ClassroomRecord;
use App\Livewire\Admin\EditStudentData;
use App\Livewire\Admin\EnrollStudent;
use App\Livewire\Admin\ExamRecord;
use App\Livewire\Admin\SchoolYearRecord;
use App\Livewire\Admin\StudentRecord;
use App\Livewire\Admin\TeacherRecord;
use App\Livewire\Enrollment;
use App\Livewire\Guidance\GuidanceDashboard;
use App\Livewire\StudentDashboard;
use App\Livewire\Student\GradeRecord;
use App\Livewire\Teacher\ManageGrade;
use App\Livewire\Teacher\SubjectAttendance;
use App\Livewire\Teacher\SubjectGrade;
use App\Livewire\Teacher\TeacherStudent;
use App\Livewire\Teacher\TeacherSubjectRecord;
use Illuminate\Support\Facades\Route;

Route::get('/dashboard', function () {
    switch (auth()->user()->role) {
        case 'admin':
            return redirect()->route('admin.dashboard');
        case 'teacher':
            return redirect()->route('teacher.dashboard');
        case 'student':
            return redirect()->route('student.dashboard');
        case 'encoder':
            return redirect()->route('encoder.dashboard');
        case 'guidance':
            return redirect()->route('guidance.dashboard');
        default:
            # code...
            break;
    }
})->name('dashboard');

Route::prefix('administrator')->middleware(['auth', 'verified'])->group(function () {
    Route::get('/', AdminDashboard::class)->name('admin.dashboard');
    Route::get('/school-year', SchoolYearRecord::class)->name('admin.school-year');
    Route::get('/teacher', TeacherRecord::class)->name('admin.teacher');
    Route::get('/classroom', ClassroomRecord::class)->name('admin.classroom');
    Route::get('/enrollment', Enrollment::class)->name('admin.enrollment');
    Route::get('/enroll-student', EnrollStudent::class)->name('admin.enroll-student');
    Route::get('/student', StudentRecord::class)->name('admin.student');
    Route::get('/exam', ExamRecord::class)->name('admin.exam');
    Route::get('/grades', ExamRecord::class)->name('admin.grades');
    Route::get('/student-data/edit/{id}', EditStudentData::class)->name('admin.edit-student-data');
});

Route::prefix('teacher')->middleware(['auth', 'verified'])->group(function () {
    Route::get('/', AdminDashboard::class)->name('teacher.dashboard');
    Route::get('/student', TeacherStudent::class)->name('teacher.student');
    Route::get('/subject', TeacherSubjectRecord::class)->name('teacher.subject');
    Route::get('/attendances/{id}', SubjectAttendance::class)->name('teacher.subject.attendance');
    Route::get('/grades/{id}', SubjectGrade::class)->name('teacher.subject.grade');
    Route::get('/manage-grades/{id}', ManageGrade::class)->name('teacher.manage-grade');
});

Route::prefix('guidance')->middleware(['auth', 'verified'])->group(function () {
    Route::get('/', GuidanceDashboard::class)->name('guidance.dashboard');
});

Route::prefix('student')->middleware(['auth', 'verified'])->group(function () {
    Route::get('/', StudentDashboard::class)->name('student.dashboard');
    Route::get('/grade', GradeRecord::class)->name('student.grade');
});

Route::prefix('encoder')->middleware(['auth', 'verified'])->group(function () {
    Route::get('/', Enrollment::class)->name('encoder.dashboard');
    Route::get('/enroll-student', EnrollStudent::class)->name('encoder.enroll-student');
  
});

Route::get('/', function () {
    return view('welcome');
});

Route::view('profile', 'profile')
    ->middleware(['auth'])
    ->name('profile');

require __DIR__ . '/auth.php';
